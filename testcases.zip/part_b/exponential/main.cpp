#include <iostream>
using namespace std;

int main() {
    int a,b,res;
    cin >> a >> b;
    res=a;
    for(int tmp=1; tmp<b; tmp++) res*=a;
    cout << res << endl;
    return 0;
}
