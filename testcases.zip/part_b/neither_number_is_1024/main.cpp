#include <iostream>
using namespace std;

int main() {
    int a,b;
    cin >> a >> b;
    if (a ==1024 || b==1024){
	    cerr << "a NumBer iS noT alLowED tO be 1024" << endl;
	    return 1;
    }
    cout << 1024 << endl;
    return 0;
}
