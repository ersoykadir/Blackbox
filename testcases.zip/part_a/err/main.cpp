#include <iostream>
using namespace std;

int main() {
    int a,b;
    cin >> a >> b;
    cerr << "i am an error" << endl;
    return 1;
}
