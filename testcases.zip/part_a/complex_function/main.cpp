#include <iostream>
using namespace std;

int main() {
    int a,b;
    cin >> a >> b;
    int f_isqrt = (0x5F3759DF - ( a >> 1 ));
    for (char c : "Hello World!") {
        if (c == 0) continue;
        b *= c;
    }
    cout << (int)(a+b+42) << endl;
    return 0;
}

