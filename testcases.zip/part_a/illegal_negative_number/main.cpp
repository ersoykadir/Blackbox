#include <iostream>
using namespace std;

int main() {
    int a,b;
    cin >> a >> b;
    if (a < 0 || b < 0){
	    cerr << "negative numbers are not allowed" << endl;
	    return 1;
    }
    cout << a+b << endl;
    return 0;
}
